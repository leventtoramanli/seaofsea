<?php
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Crud.php';
require_once __DIR__ . '/FileHandler.php';
require_once __DIR__ . '/company_announcementhandler.php';

/*{"v":1,"perms":{"company.ann.create":{"a":"grant","by":26,"at":"2025-08-29 10:59:21"},"company.ann.archive":{"a":"grant","by":26,"at":"2025-08-29 10:59:21"}}}*/

class CompanyJobHandler
{
    // Router bridge’leri (module=job, action=…)
    public static function apply_job(array $p = []): array                    { return self::apply($p); }
    public static function create(array $p = []): array                       { return self::createJob($p); }
    public static function publish(array $p = []): array                      { return self::publishJob($p); }
    public static function close(array $p = []): array                        { return self::closeJob($p); }
    public static function list(array $p = []): array                         { return self::listJobs($p); }
    public static function detail(array $p = []): array                       { return self::detailJob($p); }
    public static function my_applications(array $p = []): array              { return self::myApplications($p); }
    public static function applications(array $p = []): array                 { return self::applicationsForCompanyOrJob($p); }
    public static function application_update_status(array $p = []): array    { return self::updateApplicationStatus($p); }
    public static function application_withdraw(array $p = []): array         { return self::withdrawApplication($p); }
    public static function search(array $p = []): array                       { return self::searchJobs($p); }
    public static function update(array $p = []): array                       { return self::updateJob($p); }
    public static function archive(array $p = []): array                      { return self::archiveJob($p); }
    public static function reopen(array $p = []): array                       { return self::reopenJob($p); }
    public static function delete(array $p = []): array                       { return self::softDeleteJob($p); }
    public static function undelete(array $p = []): array                     { return self::unDeleteJob($p); }

    /* ===========================
     * REQUIREMENTS Normalizasyonu
     * =========================== */

    private static function normalizeEducation(string $raw): string
    {
        // Kanonik: primary|middle|highschool|associate|bachelor|master|phd
        $v = mb_strtolower(trim($raw), 'UTF-8');
        $map = [
            // primary
            'primary' => 'primary',
            'primary school' => 'primary',
            'ilkokul' => 'primary',
            'elementary' => 'primary',

            // middle
            'middle' => 'middle',
            'middle school' => 'middle',
            'ortaokul' => 'middle',

            // highschool
            'high school' => 'highschool',
            'highschool'  => 'highschool',
            'lise'        => 'highschool',

            // associate
            'associate' => 'associate',
            'associate degree' => 'associate',
            'önlisans' => 'associate',
            'onlisans' => 'associate',

            // bachelor / undergraduate
            'bachelor' => 'bachelor',
            'undergraduate' => 'bachelor',
            'lisans' => 'bachelor',

            // master
            'master' => 'master',
            'yüksek lisans' => 'master',
            'yuksek lisans' => 'master',
            'yukseklisans' => 'master',
            'msc' => 'master',

            // phd / doctorate
            'phd' => 'phd',
            'doctorate' => 'phd',
            'doktora' => 'phd',
        ];
        return $map[$v] ?? 'highschool';
    }

    private static function normalizeIdList($v): array
    {
        if (is_string($v)) {
            $v = preg_split('/[,\s]+/', $v, -1, PREG_SPLIT_NO_EMPTY);
        }
        if (!is_array($v)) return [];
        $ids = [];
        foreach ($v as $x) {
            $n = (int)filter_var($x, FILTER_SANITIZE_NUMBER_INT);
            if ($n > 0) $ids[] = $n;
        }
        sort($ids, SORT_NUMERIC);
        return $ids;
    }

    private static function filterExistingCertificateIds(Crud $crud, array $ids): array
    {
        if (empty($ids)) return [];
        $in = implode(',', array_fill(0, count($ids), '?'));
        $rows = $crud->query("SELECT id FROM certificates WHERE id IN ($in)", $ids) ?: [];
        $ok = [];
        foreach ($rows as $r) $ok[] = (int)$r['id'];
        return array_values(array_intersect($ids, $ok));
    }

    private static function normalizeRequirements($raw, Crud $crud): array
    {
        // 1) diziye çevir
        if (is_string($raw)) {
            $raw = trim($raw);
            if ($raw === '') {
                $raw = [];
            } else {
                $dec = json_decode($raw, true);
                $raw = is_array($dec) ? $dec : [];
            }
        } elseif (!is_array($raw)) {
            $raw = [];
        }

        // 2) anahtarlar
        $edu = $raw['min_education'] ?? $raw['education'] ?? $raw['minEducation'] ?? null;
        $eduCanon = $edu ? self::normalizeEducation((string)$edu) : 'highschool';

        $mustRaw = $raw['certificates']
            ?? $raw['required_certificates']
            ?? $raw['must']
            ?? $raw['required']
            ?? [];
        $optRaw  = $raw['optional_certificates']
            ?? $raw['optional']
            ?? $raw['nice_to_have']
            ?? [];

        $mustIds = self::normalizeIdList($mustRaw);
        $optIds  = self::normalizeIdList($optRaw);

        $minYears = null;
        if (isset($raw['min_years']) || isset($raw['experience']) || isset($raw['minYears'])) {
            $val = $raw['min_years'] ?? $raw['experience'] ?? $raw['minYears'];
            $n = (int)filter_var($val, FILTER_SANITIZE_NUMBER_INT);
            if ($n < 0) $n = 0;
            if ($n > 60) $n = 60;
            $minYears = $n;
        }

        $notes = null;
        if (isset($raw['notes']) || isset($raw['note'])) {
            $notes = trim((string)($raw['notes'] ?? $raw['note'] ?? ''));
            if ($notes === '') $notes = null;
        }

        // 3) ID doğrulama
        $mustIds = self::filterExistingCertificateIds($crud, $mustIds);
        $optIds  = self::filterExistingCertificateIds($crud, $optIds);

        // 4) kanonik çıktı
        $out = [
            'min_education' => $eduCanon,
            'certificates'  => array_values(array_unique($mustIds)),
        ];
        if (!empty($optIds))       $out['optional_certificates'] = array_values(array_unique($optIds));
        if ($minYears !== null)    $out['min_years'] = $minYears;
        if ($notes !== null)       $out['notes'] = $notes;

        return $out;
    }

    /* ===========================
     * JOB: create / update / publish / close / list / detail / search
     * =========================== */

    private static function createJob(array $p = []): array
    {
        $auth   = Auth::requireAuth();
        $userId = (int)$auth['user_id'];
        $crud   = new Crud($userId);

        $companyId  = (int)($p['company_id'] ?? 0);
        $title      = trim((string)($p['title'] ?? ''));
        $positionId = isset($p['position_id']) ? (int)$p['position_id'] : null;
        $area       = in_array(($p['area'] ?? 'crew'), ['crew','office'], true) ? $p['area'] : 'crew';
        $location   = $p['location'] ?? null;
        $visibility = in_array(($p['visibility'] ?? 'public'), ['public','followers','private'], true) ? $p['visibility'] : 'public';

        if ($companyId <= 0 || $title === '') {
            return ['created'=>false, 'error'=>'company_id_and_title_required'];
        }

        if (class_exists('PermissionService') && method_exists('PermissionService','hasPermission')) {
            if (!PermissionService::hasPermission($userId, 'job.create', $companyId)) {
                return ['created'=>false, 'error'=>'not_authorized'];
            }
        }

        $payload = [
            'company_id'  => $companyId,
            'position_id' => $positionId ?: null,
            'title'       => $title,
            'description' => null,
            'requirements'=> null,
            'area'        => $area,
            'location'    => $location ?: null,
            'visibility'  => $visibility,
            'status'      => 'open',
            'created_by'  => $userId,
            'opened_at'   => date('Y-m-d H:i:s'),
            'created_at'  => date('Y-m-d H:i:s'),
            'updated_at'  => null,
        ];

        // Description
        if (array_key_exists('description', $p)) {
            $desc = $p['description'];
            $payload['description'] = is_string($desc)
                ? $desc
                : (is_array($desc) ? json_encode($desc, JSON_UNESCAPED_UNICODE) : null);
        }

        // Requirements (normalizasyon)
        if (array_key_exists('requirements', $p)) {
            $req = self::normalizeRequirements($p['requirements'], $crud);
            $payload['requirements'] = json_encode($req, JSON_UNESCAPED_UNICODE);
        }

        // notify_followers flag’i opsiyonel tut
        if (isset($p['notify_followers'])) {
            $payload['notify_followers'] = (int)!!$p['notify_followers'];
        }

        $jid = $crud->create('job_posts', array_filter($payload, fn($v)=>$v!==null));
        if (!$jid) return ['created'=>false, 'error'=>'db_create_failed'];

        // Takipçilere duyuru (opsiyonel)
        $notifyFollowers = (int)($p['notify_followers'] ?? 0) === 1;
        if ($visibility === 'followers' || $notifyFollowers) {
            if (class_exists('CompanyNotificationHandler') && method_exists('CompanyNotificationHandler','push_job_post_internal')) {
                CompanyNotificationHandler::push_job_post_internal((int)$jid);
            }
        }

        return ['created'=>true, 'id'=>(int)$jid];
    }

    private static function updateJob(array $p = []): array
    {
        $auth  = Auth::requireAuth();
        $actor = (int)$auth['user_id'];
        $crud  = new Crud($actor);

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['updated'=>false, 'error'=>'id_required'];

        $job = $crud->read('job_posts', ['id'=>$id], ['id','company_id','deleted_at'], false);
        if (!$job) return ['updated'=>false, 'error'=>'not_found'];
        if (!empty($job['deleted_at'])) return ['updated'=>false, 'error'=>'deleted'];

        $cid = (int)$job['company_id'];
        if (class_exists('PermissionService') && method_exists('PermissionService','hasPermission')) {
            if (!PermissionService::hasPermission($actor, 'job.update', $cid)) {
                return ['updated'=>false, 'error'=>'not_authorized'];
            }
        }

        $upd = ['updated_at' => date('Y-m-d H:i:s')];

        if (array_key_exists('title', $p)) {
            $t = trim((string)$p['title']);
            if ($t !== '') $upd['title'] = $t;
        }
        if (array_key_exists('area', $p)) {
            $a = (string)$p['area'];
            if (in_array($a, ['crew','office'], true)) $upd['area'] = $a;
        }
        if (array_key_exists('visibility', $p)) {
            $v = (string)$p['visibility'];
            if (in_array($v, ['public','followers','private'], true)) $upd['visibility'] = $v;
        }
        if (array_key_exists('position_id', $p)) {
            $upd['position_id'] = isset($p['position_id']) ? (int)$p['position_id'] : null;
        }
        if (array_key_exists('description', $p)) {
            $d = $p['description'];
            $upd['description'] = is_string($d) ? $d : (is_array($d) ? json_encode($d, JSON_UNESCAPED_UNICODE) : null);
        }
        if (array_key_exists('location', $p)) {
            $upd['location'] = (string)$p['location'];
        }
        if (array_key_exists('requirements', $p)) {
            $req = self::normalizeRequirements($p['requirements'], $crud);
            $upd['requirements'] = json_encode($req, JSON_UNESCAPED_UNICODE);
        }

        if (count($upd) <= 1) return ['updated'=>true]; // no-op

        $ok = $crud->update('job_posts', $upd, ['id'=>$id]);
        return ['updated'=>(bool)$ok, 'id'=>$id];
    }

    private static function publishJob(array $p): array
    {
        $auth   = Auth::requireAuth();
        $userId = (int)$auth['user_id'];
        $crud   = new Crud($userId);

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['published'=>false, 'error'=>'id_required'];

        $job = $crud->read('job_posts', ['id'=>$id], ['id','company_id','status'], false);
        if (!$job) return ['published'=>false, 'error'=>'not_found'];

        $allowed = class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
            ? PermissionService::hasPermission($userId, 'job.publish', (int)$job['company_id'])
            : false;
        if (!$allowed) return ['published'=>false, 'error'=>'not_authorized'];

        $ok = $crud->update('job_posts', [
            'status'    => 'open',
            'opened_at' => date('Y-m-d H:i:s'),
            'updated_at'=> date('Y-m-d H:i:s'),
        ], ['id'=>$id]);

        return ['published'=>(bool)$ok, 'id'=>$id];
    }

    private static function closeJob(array $p): array
    {
        $auth   = Auth::requireAuth();
        $userId = (int)$auth['user_id'];
        $crud   = new Crud($userId);

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['closed'=>false, 'error'=>'id_required'];

        $job = $crud->read('job_posts', ['id'=>$id], ['id','company_id','status'], false);
        if (!$job) return ['closed'=>false, 'error'=>'not_found'];

        $allowed = class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
            ? PermissionService::hasPermission($userId, 'job.close', (int)$job['company_id'])
            : false;
        if (!$allowed) return ['closed'=>false, 'error'=>'not_authorized'];

        $ok = $crud->update('job_posts', [
            'status'    => 'closed',
            'closed_at' => date('Y-m-d H:i:s'),
            'updated_at'=> date('Y-m-d H:i:s'),
        ], ['id'=>$id]);

        return ['closed'=>(bool)$ok, 'id'=>$id];
    }

    private static function listJobs(array $p): array
    {
        $auth = Auth::check();
        $uid  = $auth ? (int)$auth['user_id'] : null;
        $crud = $uid ? new Crud($uid) : new Crud();

        $companyId  = isset($p['company_id']) ? (int)$p['company_id'] : null;
        $status     = $p['status'] ?? 'open';
        $visibility = $p['visibility'] ?? null; // opsiyonel: public|followers|private

        $page    = max(1, (int)($p['page'] ?? 1));
        $perPage = max(1, min(100, (int)($p['perPage'] ?? 25)));
        $offset  = ($page - 1) * $perPage;

        $where  = [];
        $params = [];
        if ($companyId) { $where[] = "j.company_id = :c"; $params[':c'] = $companyId; }
        if ($status)    { $where[] = "j.status = :s";     $params[':s'] = $status;    }
        $whereSql = $where ? (" WHERE ".implode(" AND ", $where)." AND j.deleted_at IS NULL") : "WHERE j.deleted_at IS NULL";

        $rows = $crud->query("
            SELECT j.*
            FROM job_posts j
            {$whereSql}
            ORDER BY j.created_at DESC
            LIMIT 1000
        ", $params) ?: [];

        $out = [];
        foreach ($rows as $row) {
            $vis = $row['visibility'] ?? 'public';
            $cid = (int)$row['company_id'];

            if ($vis === 'public') { $out[] = $row; continue; }

            if ($vis === 'followers') {
                if ($uid) {
                    $isFollower = (bool)$crud->query("
                        SELECT 1 FROM company_followers
                        WHERE company_id = :c AND user_id = :u AND unfollow IS NULL
                        LIMIT 1
                    ", [':c'=>$cid, ':u'=>$uid]);
                    if ($isFollower) $out[] = $row;
                }
                continue;
            }

            if ($vis === 'private') {
                if ($uid && class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
                    && PermissionService::hasPermission($uid, 'job.update', $cid)) {
                    $out[] = $row;
                }
                continue;
            }
        }

        if ($visibility && in_array($visibility, ['public','followers','private'], true)) {
            $out = array_values(array_filter($out, fn($r)=> ($r['visibility'] ?? 'public') === $visibility));
        }

        $total = count($out);
        $items = array_slice($out, $offset, $perPage);

        return ['items'=>$items, 'page'=>$page, 'perPage'=>$perPage, 'total'=>$total];
    }

    private static function detailJob(array $p): array
    {
        $auth = Auth::check();
        $uid  = $auth ? (int)$auth['user_id'] : null;
        $crud = $uid ? new Crud($uid) : new Crud();

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['found'=>false, 'error'=>'id_required'];

        $row = $crud->read('job_posts', ['id'=>$id], ['*'], false);
        if (!$row) return ['found'=>false, 'error'=>'not_found'];
        if (!empty($row['deleted_at'])) return ['found'=>false, 'error'=>'not_found'];

        $vis = $row['visibility'] ?? 'public';
        $cid = (int)$row['company_id'];

        if ($vis === 'public') return $row;

        if ($vis === 'followers') {
            if (!$uid) return ['found'=>false, 'error'=>'auth_required'];
            $isFollower = (bool)$crud->query("
                SELECT 1 FROM company_followers
                WHERE company_id = :c AND user_id = :u AND unfollow IS NULL
                LIMIT 1
            ", [':c'=>$cid, ':u'=>$uid]);
            if ($isFollower) return $row;
            return ['found'=>false, 'error'=>'not_authorized'];
        }

        if ($vis === 'private') {
            if (!$uid) return ['found'=>false, 'error'=>'auth_required'];
            if (class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
                && PermissionService::hasPermission($uid, 'job.update', $cid)) {
                return $row;
            }
            return ['found'=>false, 'error'=>'not_authorized'];
        }

        return ['found'=>false];
    }

    private static function searchJobs(array $p): array
    {
        $auth = Auth::check();
        $uid  = $auth ? (int)$auth['user_id'] : null;
        $crud = $uid ? new Crud($uid) : new Crud();

        $q             = trim((string)($p['q'] ?? ''));
        $companyId     = isset($p['company_id'])  ? (int)$p['company_id']  : null;
        $positionId    = isset($p['position_id']) ? (int)$p['position_id'] : null;
        $area          = in_array(($p['area'] ?? ''), ['crew','office'], true) ? $p['area'] : null;
        $status        = ($p['status'] ?? 'open');
        $visibilityF   = $p['visibility'] ?? null;
        $followingOnly = (int)($p['following_only'] ?? 0) === 1;

        $page    = max(1, (int)($p['page'] ?? 1));
        $perPage = max(1, min(100, (int)($p['perPage'] ?? 25)));
        $offset  = ($page - 1) * $perPage;

        // takip edilenler
        $followed = [];
        if ($uid) {
            $rowsF = $crud->query("
                SELECT company_id FROM company_followers
                WHERE user_id = :u AND unfollow IS NULL
            ", [':u'=>$uid]) ?: [];
            foreach ($rowsF as $r) $followed[(int)$r['company_id']] = true;
        }

        // filtreler
        $where  = [];
        $params = [];
        if ($companyId)  { $where[] = "j.company_id = :company_id";   $params[':company_id']  = $companyId; }
        if ($positionId) { $where[] = "j.position_id = :position_id"; $params[':position_id'] = $positionId; }
        if ($area)       { $where[] = "j.area = :area";               $params[':area']        = $area; }
        if ($status && $status !== 'any') { $where[] = "j.status = :status"; $params[':status'] = $status; }
        $whereSql = $where ? (' WHERE ' . implode(' AND ', $where) . ' AND j.deleted_at IS NULL') : ' WHERE j.deleted_at IS NULL';

        $joinFollow = '';
        if ($followingOnly && $uid) {
            $joinFollow = " JOIN company_followers f
                            ON f.company_id = j.company_id
                        AND f.user_id    = :uid
                        AND f.unfollow  IS NULL ";
            $params[':uid'] = $uid;
        }

        if (mb_strlen($q) >= 2) {
            $qBoolean = implode(' ', array_map(fn($w)=> (strlen($w)>=2 ? $w.'*' : $w), preg_split('/\s+/', $q)));
            $paramsFT = $params + [':q' => $qBoolean];

            $sqlFT = "SELECT j.*, MATCH(j.title, j.description) AGAINST (:q IN BOOLEAN MODE) AS _score
                      FROM job_posts j
                      {$joinFollow}
                      {$whereSql}
                      AND MATCH(j.title, j.description) AGAINST (:q IN BOOLEAN MODE)
                      ORDER BY _score DESC, j.created_at DESC
                      LIMIT 1000";
            $rows = $crud->query($sqlFT, $paramsFT);

            if ($rows === false) {
                $like = '%'.$q.'%';
                $paramsLike = $params + [':ql'=>$like];
                $whereLike = $whereSql.' AND (j.title LIKE :ql OR j.description LIKE :ql OR j.requirements LIKE :ql)';
                $rows = $crud->query("
                    SELECT j.* FROM job_posts j
                    {$joinFollow}
                    {$whereLike}
                    ORDER BY j.created_at DESC
                    LIMIT 1000
                ", $paramsLike) ?: [];
            }
        } else {
            $rows = $crud->query("
                SELECT j.* FROM job_posts j
                {$joinFollow}
                {$whereSql}
                ORDER BY j.created_at DESC
                LIMIT 1000
            ", $params) ?: [];
        }

        // görünürlük süzme
        $filtered = [];
        foreach ($rows as $r) {
            $vis = $r['visibility'] ?? 'public';
            $cid = (int)$r['company_id'];

            if ($vis === 'public') { $filtered[] = $r; continue; }
            if ($vis === 'followers') {
                if ($uid && isset($followed[$cid])) $filtered[] = $r;
                continue;
            }
            if ($vis === 'private') {
                if ($uid && class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
                    && PermissionService::hasPermission($uid, 'job.update', $cid)) {
                    $filtered[] = $r;
                }
                continue;
            }
        }

        if ($visibilityF && in_array($visibilityF, ['public','followers','private'], true)) {
            $filtered = array_values(array_filter($filtered, fn($x)=> ($x['visibility'] ?? 'public') === $visibilityF));
        }

        $total = count($filtered);
        $items = array_slice($filtered, $offset, $perPage);

        return ['items'=>$items, 'page'=>$page, 'perPage'=>$perPage, 'total'=>$total];
    }

    /* ===========================
     * APPLICATION: create/apply / list / status / withdraw
     * =========================== */

    private static function apply(array $p): array
    {
        $auth   = Auth::requireAuth();
        $userId = (int)$auth['user_id'];
        $crud   = new Crud($userId);

        $jobId   = isset($p['job_id']) ? (int)$p['job_id'] : 0;
        $message = trim((string)($p['message'] ?? ''));

        if ($jobId <= 0) return ['success'=>false, 'error'=>'job_id_required'];

        $job = $crud->read('job_posts', ['id' => $jobId], ['id','company_id','status','visibility'], false);
        if (!$job) return ['success'=>false, 'error'=>'job_not_found'];

        $companyId  = (int)$job['company_id'];
        $visibility = (string)$job['visibility'];
        $status     = (string)$job['status'];

        if ($status !== 'open') {
            return ['success'=>false, 'error'=>'job_not_open'];
        }

        // Görünürlük kuralları
        if ($visibility === 'followers') {
            $isFollower = (bool)$crud->query("
                SELECT 1 FROM company_followers
                WHERE company_id = :c AND user_id = :u AND unfollow IS NULL
                LIMIT 1
            ", [':c'=>$companyId, ':u'=>$userId]);
            if (!$isFollower) return ['success'=>false, 'error'=>'not_authorized_followers_only'];
        } elseif ($visibility === 'private') {
            if (!(class_exists('PermissionService') && PermissionService::hasPermission($userId, 'job.update', $companyId))) {
                return ['success'=>false, 'error'=>'not_authorized_private'];
            }
        }

        // Duplicate kontrol (aktif başvuru var mı?)
        $dup = $crud->query("
            SELECT 1 FROM job_applications
            WHERE job_id = :j AND user_id = :u AND status NOT IN ('withdrawn','rejected')
            LIMIT 1
        ", [':j'=>$jobId, ':u'=>$userId]);
        if ($dup) return ['success'=>false, 'error'=>'already_applied'];

        // CV Snapshot
        $cvRow = $crud->read('user_cv', ['user_id' => $userId], ['*'], false);
        $cvSnap = null;
        if ($cvRow) {
            $cvSnapArr = [
                'professional_title' => $cvRow['professional_title'] ?? null,
                'basic_info'         => $cvRow['basic_info'] ?? null,
                'language'           => self::jsonMaybe($cvRow['language'] ?? null),
                'education'          => self::jsonMaybe($cvRow['education'] ?? null),
                'work_experience'    => self::jsonMaybe($cvRow['work_experience'] ?? null),
                'skills'             => self::jsonMaybe($cvRow['skills'] ?? null),
                'certificates'       => self::jsonMaybe($cvRow['certificates'] ?? null),
                'seafarer_info'      => self::jsonMaybe($cvRow['seafarer_info'] ?? null),
                'references'         => self::jsonMaybe($cvRow['references'] ?? null),
            ];
            $cvSnap = json_encode($cvSnapArr, JSON_UNESCAPED_UNICODE);
        }

        // Dosyalar (opsiyonel)
        $attachments = [];
        $savedFileLegacy = null;

        if (!empty($p['file_name']) && !empty($p['file_data'])) {
            $fn  = basename((string)$p['file_name']);
            $raw = base64_decode((string)$p['file_data'], true);
            if ($raw !== false) {
                $folder = 'job_applications';
                $fh = new FileHandler();
                $path = $fh->createFolderPath($folder) . $fn;
                file_put_contents($path, $raw);
                $attachments[] = $fn;
                $savedFileLegacy = $fn;
            }
        }

        if (!empty($p['attachments']) && is_array($p['attachments'])) {
            $fh = new FileHandler();
            $dir = $fh->createFolderPath('job_applications');
            if (!is_dir($dir)) { @mkdir($dir, 0777, true); }

            foreach ($p['attachments'] as $item) {
                $orig2 = trim((string)($item['file_name'] ?? ''));
                $raw2  = base64_decode((string)($item['file_data_base64'] ?? ''), true);
                if ($orig2 !== '' && $raw2 !== false) {
                    $ext2 = strtolower(pathinfo($orig2, PATHINFO_EXTENSION));
                    $allowed = ['pdf','jpg','jpeg','png','webp'];
                    if (in_array($ext2, $allowed, true)) {
                        $fn2 = 'app_' . uniqid('', true) . '.' . $ext2;
                        $path2 = $dir . $fn2;
                        if (file_put_contents($path2, $raw2) !== false) {
                            $attachments[] = $fn2;
                        }
                    }
                }
            }
        }

        $aid = $crud->create('job_applications', [
            'job_id'      => $jobId,
            'company_id'  => $companyId,
            'user_id'     => $userId,
            'status'      => 'submitted',
            'message'     => $message !== '' ? $message : null,
            'cv_snapshot' => $cvSnap,
            'attachments' => $attachments ? json_encode($attachments, JSON_UNESCAPED_UNICODE) : null,
            'file_name'   => $savedFileLegacy, // legacy kolon
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
        if (!$aid) return ['success'=>false, 'error'=>'db_create_failed'];

        // Şirket tarafına bildirim
        if (class_exists('CompanyNotificationHandler') && method_exists('CompanyNotificationHandler','push_application_new_internal')) {
            CompanyNotificationHandler::push_application_new_internal($jobId, $userId);
        }

        return ['success'=>true, 'id'=>(int)$aid];
    }

    private static function jsonMaybe($v) {
        if (is_string($v)) {
            $j = json_decode($v, true);
            return is_array($j) ? $j : $v;
        }
        return $v;
    }

    private static function myApplications(array $p): array
    {
        $auth   = Auth::requireAuth();
        $userId = (int)$auth['user_id'];
        $crud   = new Crud($userId);

        $status  = $p['status'] ?? null;
        $page    = max(1, (int)($p['page'] ?? 1));
        $perPage = max(1, min(100, (int)($p['perPage'] ?? 25)));
        $offset  = ($page - 1) * $perPage;

        // COUNT
        $sqlCount = "
            SELECT COUNT(*) AS c
            FROM job_applications a
            JOIN job_posts j ON j.id = a.job_id
            WHERE a.user_id = :u
            ".($status ? " AND a.status = :s" : "")."
        ";
        $params = [':u'=>$userId];
        if ($status) $params[':s'] = $status;

        $rowC  = $crud->query($sqlCount, $params);
        $total = (int)($rowC[0]['c'] ?? 0);

        // ITEMS — LIMIT/OFFSET'i doğrudan tamsayı olarak koyuyoruz
        $sql = "
            SELECT a.id, a.status, a.created_at, a.updated_at,
                j.id AS job_id, j.title, j.company_id,
                c.name AS company_name, j.area, j.location
            FROM job_applications a
            JOIN job_posts j ON j.id = a.job_id
            JOIN companies  c ON c.id = j.company_id
            WHERE a.user_id = :u
            ".($status ? " AND a.status = :s" : "")."
            ORDER BY a.created_at DESC
            LIMIT {$perPage} OFFSET {$offset}
        ";
        $items = $crud->query($sql, $params) ?: [];

        return ['items'=>$items, 'page'=>$page, 'perPage'=>$perPage, 'total'=>$total];
    }

    private static function applicationsForCompanyOrJob(array $p): array
    {
        $auth   = Auth::requireAuth();
        $actor  = (int)$auth['user_id'];
        $crud   = new Crud($actor);

        $companyId = isset($p['company_id']) ? (int)$p['company_id'] : null;
        $jobId     = isset($p['job_id']) ? (int)$p['job_id'] : null;
        $status    = $p['status'] ?? null;

        $page    = max(1, (int)($p['page'] ?? 1));
        $perPage = max(1, min(100, (int)($p['perPage'] ?? 25)));
        $offset  = ($page - 1) * $perPage;

        if (!$companyId && !$jobId) {
            return ['items'=>[], 'error'=>'company_id_or_job_id_required', 'page'=>$page, 'perPage'=>$perPage, 'total'=>0];
        }
        if (!$companyId && $jobId) {
            $row = $crud->read('job_posts', ['id'=>$jobId], ['company_id'], false);
            if (!$row) return ['items'=>[], 'error'=>'job_not_found', 'page'=>$page, 'perPage'=>$perPage, 'total'=>0];
            $companyId = (int)$row['company_id'];
        }

        // Yetki: company admin || job.applications.view
        $isAdmin = (bool)$crud->query("
            SELECT 1
            FROM company_users cu
            JOIN roles r ON r.id = cu.role_id
            WHERE cu.user_id = :u AND cu.company_id = :c
            AND r.scope = 'company' AND r.name = 'admin'
            LIMIT 1
        ", [':u'=>$actor, ':c'=>$companyId]);

        $hasPerm = class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
            ? PermissionService::hasPermission($actor, 'job.applications.view', $companyId)
            : false;

        if (!($isAdmin || $hasPerm)) {
            return ['items'=>[], 'error'=>'not_authorized', 'page'=>$page, 'perPage'=>$perPage, 'total'=>0];
        }

        // COUNT
        $sqlCount = "
            SELECT COUNT(*) AS c
            FROM job_applications a
            JOIN job_posts j ON j.id = a.job_id
            JOIN users u ON u.id = a.user_id
            WHERE a.company_id = :c
            ".($jobId ? " AND a.job_id = :j" : "")."
            ".($status ? " AND a.status = :s" : "")."
        ";
        $params = [':c'=>$companyId];
        if ($jobId)  $params[':j'] = $jobId;
        if ($status) $params[':s'] = $status;

        $rowC  = $crud->query($sqlCount, $params);
        $total = (int)($rowC[0]['c'] ?? 0);

        // ITEMS — LIMIT/OFFSET'i doğrudan tamsayı olarak koyuyoruz
        $sql = "
            SELECT a.id, a.status, a.created_at, a.updated_at, a.user_id,
                u.name, u.surname, u.email, u.user_image,
                j.id AS job_id, j.title
            FROM job_applications a
            JOIN job_posts j ON j.id = a.job_id
            JOIN users u ON u.id = a.user_id
            WHERE a.company_id = :c
            ".($jobId ? " AND a.job_id = :j" : "")."
            ".($status ? " AND a.status = :s" : "")."
            ORDER BY a.created_at DESC
            LIMIT {$perPage} OFFSET {$offset}
        ";
        $items = $crud->query($sql, $params) ?: [];

        return ['items'=>$items, 'page'=>$page, 'perPage'=>$perPage, 'total'=>$total];
    }

    private static function updateApplicationStatus(array $p): array
    {
        $auth   = Auth::requireAuth();
        $userId = (int)$auth['user_id'];
        $crud   = new Crud($userId);

        $appId  = (int)($p['application_id'] ?? $p['id'] ?? 0);
        $status = (string)($p['status'] ?? '');
        $allowed = ['submitted','under_review','shortlisted','rejected','withdrawn','hired'];

        if ($appId <= 0) return ['updated'=>false, 'error'=>'application_id_required'];
        if (!in_array($status, $allowed, true)) return ['updated'=>false, 'error'=>'invalid_status'];

        $a = $crud->read('job_applications', ['id'=>$appId], ['id','job_id','company_id','user_id','status'], false);
        if (!$a) return ['updated'=>false, 'error'=>'not_found'];

        $companyId = (int)$a['company_id'];
        $authorized = false;
        if (class_exists('PermissionService') && method_exists('PermissionService','hasPermission')) {
            $authorized = PermissionService::hasPermission($userId, 'application.review', $companyId)
                     ||  PermissionService::hasPermission($userId, 'job.update', $companyId);
        }
        if (!$authorized) return ['updated'=>false, 'error'=>'not_authorized'];

        $ok = $crud->update('job_applications', [
            'status'     => $status,
            'updated_at' => date('Y-m-d H:i:s'),
        ], ['id'=>$appId]);

        if ($ok && class_exists('CompanyNotificationHandler') && method_exists('CompanyNotificationHandler','push_application_status_internal')) {
            CompanyNotificationHandler::push_application_status_internal(
                (int)$a['job_id'], (int)$a['user_id'], $status
            );
        }
        return ['updated'=>(bool)$ok, 'id'=>$appId, 'status'=>$status];
    }

    private static function withdrawApplication(array $p): array
    {
        $auth   = Auth::requireAuth();
        $userId = (int)$auth['user_id'];
        $crud   = new Crud($userId);

        $appId = (int)($p['application_id'] ?? $p['id'] ?? 0);
        if ($appId <= 0) return ['withdrawn'=>false, 'error'=>'application_id_required'];

        $a = $crud->read('job_applications', ['id'=>$appId], ['id','user_id','status'], false);
        if (!$a) return ['withdrawn'=>false, 'error'=>'not_found'];
        if ((int)$a['user_id'] !== $userId) return ['withdrawn'=>false, 'error'=>'not_owner'];

        if (in_array($a['status'], ['rejected','hired'], true)) {
            return ['withdrawn'=>false, 'error'=>'finalized'];
        }

        $ok = $crud->update('job_applications', [
            'status'     => 'withdrawn',
            'updated_at' => date('Y-m-d H:i:s'),
        ], ['id'=>$appId]);

        return ['withdrawn'=>(bool)$ok, 'id'=>$appId];
    }

    /* ===========================
     * ARCHIVE / REOPEN / SOFT-DELETE / UNDELETE
     * =========================== */

    private static function archiveJob(array $p): array
    {
        $auth   = Auth::requireAuth();
        $uid    = (int)$auth['user_id'];
        $crud   = new Crud($uid);

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['archived'=>false, 'error'=>'id_required'];

        $job = $crud->read('job_posts', ['id'=>$id], ['id','company_id','deleted_at'], false);
        if (!$job) return ['archived'=>false, 'error'=>'not_found'];
        if (!empty($job['deleted_at'])) return ['archived'=>false, 'error'=>'deleted'];

        $cid = (int)$job['company_id'];
        $can = class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
            ? (PermissionService::hasPermission($uid, 'job.archive', $cid) || PermissionService::hasPermission($uid, 'job.update', $cid))
            : true;

        if (!$can) return ['archived'=>false, 'error'=>'not_authorized'];

        $ok = $crud->update('job_posts', [
            'status'      => 'archived',
            'archived_at' => date('Y-m-d H:i:s'),
            'updated_at'  => date('Y-m-d H:i:s'),
        ], ['id'=>$id]);

        return ['archived'=>(bool)$ok, 'id'=>$id];
    }

    private static function reopenJob(array $p): array
    {
        $auth   = Auth::requireAuth();
        $uid    = (int)$auth['user_id'];
        $crud   = new Crud($uid);

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['reopened'=>false, 'error'=>'id_required'];

        $job = $crud->read('job_posts', ['id'=>$id], ['id','company_id','deleted_at'], false);
        if (!$job) return ['reopened'=>false, 'error'=>'not_found'];
        if (!empty($job['deleted_at'])) return ['reopened'=>false, 'error'=>'deleted'];

        $cid = (int)$job['company_id'];
        $can = class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
            ? (PermissionService::hasPermission($uid, 'job.publish', $cid) || PermissionService::hasPermission($uid, 'job.update', $cid))
            : true;

        if (!$can) return ['reopened'=>false, 'error'=>'not_authorized'];

        $ok = $crud->update('job_posts', [
            'status'      => 'open',
            'opened_at'   => date('Y-m-d H:i:s'),
            'archived_at' => null,
            'closed_at'   => null,
            'updated_at'  => date('Y-m-d H:i:s'),
        ], ['id'=>$id]);

        return ['reopened'=>(bool)$ok, 'id'=>$id];
    }

    private static function softDeleteJob(array $p): array
    {
        $auth   = Auth::requireAuth();
        $uid    = (int)$auth['user_id'];
        $crud   = new Crud($uid);

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['deleted'=>false, 'error'=>'id_required'];

        $job = $crud->read('job_posts', ['id'=>$id], ['id','company_id','deleted_at'], false);
        if (!$job) return ['deleted'=>false, 'error'=>'not_found'];
        if (!empty($job['deleted_at'])) return ['deleted'=>true, 'id'=>$id]; // idempotent

        $cid = (int)$job['company_id'];
        $can = class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
            ? (PermissionService::hasPermission($uid, 'job.delete', $cid) || PermissionService::hasPermission($uid, 'job.update', $cid))
            : true;

        if (!$can) return ['deleted'=>false, 'error'=>'not_authorized'];

        $ok = $crud->update('job_posts', [
            'deleted_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ], ['id'=>$id]);

        return ['deleted'=>(bool)$ok, 'id'=>$id];
    }

    private static function unDeleteJob(array $p): array
    {
        $auth   = Auth::requireAuth();
        $uid    = (int)$auth['user_id'];
        $crud   = new Crud($uid);

        $id = (int)($p['id'] ?? 0);
        if ($id <= 0) return ['undeleted'=>false, 'error'=>'id_required'];

        $job = $crud->read('job_posts', ['id'=>$id], ['id','company_id'], false);
        if (!$job) return ['undeleted'=>false, 'error'=>'not_found'];

        $cid = (int)$job['company_id'];
        $can = class_exists('PermissionService') && method_exists('PermissionService','hasPermission')
            ? (PermissionService::hasPermission($uid, 'job.delete', $cid) || PermissionService::hasPermission($uid, 'job.update', $cid))
            : true;

        if (!$can) return ['undeleted'=>false, 'error'=>'not_authorized'];

        $ok = $crud->update('job_posts', [
            'deleted_at' => null,
            'updated_at' => date('Y-m-d H:i:s'),
        ], ['id'=>$id]);

        return ['undeleted'=>(bool)$ok, 'id'=>$id];
    }
}
