<?php

require_once __DIR__ . '/FileHandler.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Response.php';

class UploadHandler
{
    public static function upload_image($params)
    {
        $auth = Auth::requireAuth(); // Backend güvenlik kontrolü

        $fileHandler = new FileHandler();

        if (empty($_FILES['file'])) {
            Logger::error('No file uploaded. $_FILES:'. json_encode($_FILES), ['user_id' => $auth['user_id']]);
            Response::error('No file uploaded.');
            return;
        }


        $uploadResult = $fileHandler->upload($_FILES['file'], [
            'folder' => 'user/user', // profil fotoğrafları için klasör
            'prefix' => 'user_' . $auth['user_id'] . '_',
            'resize' => true,
        ]);

        if ($uploadResult['success']) {
            Response::success($uploadResult, 'Upload successful.');
            if ($uploadResult['success']) {
                // ✅ Profil resmini güncelle
                $filename = $uploadResult['filename'];
                $type = $params['type'] ?? 'user'; // 'user' veya 'cover'
                $column = $type === 'cover' ? 'cover_image' : 'user_image';

                $crud = new Crud($auth['user_id']);
                $crud->update('users', [$column => $filename], ['id' => $auth['user_id']]);

                Response::success($uploadResult, 'Upload successful.');
            }
        } else {
            Response::error($uploadResult['error'] ?? 'Upload failed.');
        }
        Logger::info('Upload result: ' . json_encode($uploadResult));
    }
}
