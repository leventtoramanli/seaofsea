<?php

require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Response.php';
require_once __DIR__ . '/../core/Crud.php';

class CvHandler
{
    public static function getCV(array $params): array
    {
        $auth = Auth::requireAuth();
        $userId = $auth['user_id'];
        $crud = new Crud($userId);

        $cv = $crud->read('user_cv', ['user_id' => $userId], fetchAll: false);
        if (!$cv) {
            return ['user_id' => $userId, 'own' => true];
        }

        return array_merge($cv, ['own' => true]);
    }

    public static function getCVByUserId(array $params): array
    {
        $viewerId = self::$userId;
        $targetId = (int) ($params['user_id'] ?? 0);

        if (!$targetId) {
            return Response::fail("User ID missing", 400);
        }

        $cv = self::$crud->read('user_cvs', ['user_id' => $targetId], fetchAll: false);
        if (!$cv) {
            $cv = ['user_id' => $targetId];
        }

        // Ülke adı
        if (!empty($cv['country_id'])) {
            $country = self::$crud->read('cities', ['id' => $cv['country_id']], ['country'], false);
            $cv['country_name'] = $country['country'] ?? null;
        }

        // Şehir adı
        if (!empty($cv['city_id'])) {
            $city = self::$crud->read('cities', ['id' => $cv['city_id']], ['city'], false);
            $cv['city_name'] = $city['city'] ?? null;
        }

        // Kullanıcı görselini users tablosundan al
        $user = self::$crud->read('users', ['id' => $targetId], ['user_image'], false);
        $cv['user_image'] = $user['user_image'] ?? null;

        $cv['own'] = ($targetId === $viewerId);
        return $cv;
    }

    public static function listCertificates(array $params): array
    {
        $auth = Auth::requireAuth();
        $crud = new Crud($auth['user_id']);

        return $crud->read('certificates', [], fetchAll: true);
    }

    public static function updateCV(array $params): array
    {
        $auth = Auth::requireAuth();
        $userId = $auth['user_id'];
        $crud = new Crud($userId);

        $allowed = [
            'basic_info',
            'professional_title',
            'country_id',
            'city_id',
            'address',
            'zip_code',
            'phone',
            'email',
            'social',
            'language',
            'education',
            'work_experience',
            'skills',
            'certificates',
            'seafarer_info',
            'references',
            'access_scope',
        ];

        $data = array_filter(
            $params,
            fn ($key) => in_array($key, $allowed),
            ARRAY_FILTER_USE_KEY
        );

        if (empty($data)) {
            return Response::fail("No valid CV fields provided", 400);
        }

        // JSON encode gereken alanlar
        $jsonFields = [
            'phone',
            'email',
            'social',
            'language',
            'education',
            'work_experience',
            'skills',
            'certificates',
            'seafarer_info',
            'references',
        ];

        foreach ($jsonFields as $field) {
            if (isset($data[$field]) && is_array($data[$field])) {
                $data[$field] = json_encode($data[$field], JSON_UNESCAPED_UNICODE);
            }
        }

        $exists = $crud->read('user_cv', ['user_id' => $userId], fetchAll: false);

        if ($exists) {
            $data['updated_at'] = date('Y-m-d H:i:s');
            $crud->update('user_cv', ['user_id' => $userId], $data);
        } else {
            $data['user_id'] = $userId;
            $data['created_at'] = date('Y-m-d H:i:s');
            $crud->create('user_cv', $data);
        }

        return ['success' => true, 'message' => 'CV updated'];
    }

}
