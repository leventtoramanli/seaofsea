<?php

require_once __DIR__ . '/../core/Response.php';
require_once __DIR__ . '/../core/JWT.php';
require_once __DIR__ . '/../core/DB.php';
require_once __DIR__ . '/../core/log.php';
require_once __DIR__ . '/../core/Crud.php';

class ProfileHandler
{
    private static Crud $crud;

    public static function init(int $userId): void
    {
        self::$crud = new Crud($userId);
    }

    public static function getProfile(array $params): void
    {
        try {
            $auth = Auth::requireAuth();
            self::init($auth['user_id']);

            $allData = self::$crud->read('users', ['id' => $auth['user_id']]);

            if (empty($allData)) {
                Response::error("User not found.", 404);
            }

            $user = $allData[0];
            $allowedFields = [
                'id', 'name', 'surname', 'email', 'role_id', 'dob', 'pob', 'gender', 'maritalStatus',
                'user_image', 'cover_image', 'bio',
                'email_notifications', 'app_notifications', 'weekly_summary'
            ];

            $filteredUser = array_intersect_key($user, array_flip($allowedFields));
            Response::success($filteredUser, 'Profile data returned.');
        } catch (Throwable $e) {
            Logger::exception($e, 'ProfileHandler::getProfile failed');
            Response::error("An unexpected error occurred while fetching profile.", 500);
        }
    }

    public static function updateProfile(array $params): void
    {
        try {
            $auth = Auth::requireAuth();
            $userId = $auth['user_id'];
            self::init($userId);

            $fieldTypes = [
                'name' => 'string',
                'surname' => 'string',
                'dob' => 'date',
                'pob' => 'nullable_string',
                'gender' => 'string',
                'maritalStatus' => 'string',
                'bio' => 'nullable_string',
                'email_notifications' => 'bool',
                'app_notifications' => 'bool',
                'weekly_summary' => 'bool',
            ];

            $data = [];

            if (!empty($params['email'])) {
                $currentUser = self::$crud->read('users', ['id' => $userId], true);
                if (!empty($currentUser)) {
                    $currentEmail = $currentUser[0]['email'] ?? null;

                    if ($params['email'] !== $currentEmail) {
                        $existing = self::$crud->read('users', ['email' => $params['email']], true);
                        if ($existing && $existing[0]['id'] != $userId) {
                            Response::error('This email is already in use.');
                        }
                        $data['email'] = $params['email'];
                        $data['is_verified'] = 0;
                    }
                }
            }

            if (!empty($params['password'])) {
                $data['password'] = password_hash($params['password'], PASSWORD_BCRYPT);
            }

            foreach ($fieldTypes as $key => $type) {
                if (array_key_exists($key, $params)) {
                    $data[$key] = self::normalizeValue($params[$key], $type);
                }
            }

            Logger::info("Updating profile", ['user_id' => $userId, 'data' => $data]);

            $success = self::$crud->update('users', $data, ['id' => $params['user_id']]);

            Logger::info("Profile update result", [
                'user_id' => $userId,
                'success' => $success,
                'data' => $data
            ]);

            if ($success) {
                Response::success(null, 'Profile updated successfully.');
            } else {
                Response::error('Profile update failed.');
            }
        } catch (Throwable $e) {
            Logger::exception($e, 'ProfileHandler::updateProfile failed');
            Response::error("An unexpected error occurred while updating profile.", 500);
        }
    }

    private static function normalizeValue($value, string $type)
    {
        $handlers = [
            'int' => fn($v) => (int) $v,
            'string' => fn($v) => trim((string) $v),
            'bool' => fn($v) => $v === true || $v === '1' || $v === 1 ? 1 : 0,
            'json' => fn($v) => json_encode($v, JSON_UNESCAPED_UNICODE),
            'date' => fn($v) => date('Y-m-d', strtotime($v)),
            'nullable_string' => fn($v) => $v !== '' ? trim($v) : null,
            'float' => fn($v) => (float) $v,
        ];

        return $handlers[$type]($value) ?? $value;
    }
}
